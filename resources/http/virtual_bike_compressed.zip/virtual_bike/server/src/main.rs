use virtual_bike::ui_main;

fn main() {
	ui_main();
}
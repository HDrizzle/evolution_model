use virtual_bike::*;
use wasm_bindgen::prelude::*;

#[wasm_bindgen]
pub fn load_map() -> JsValue {
	JsValue::NULL
}
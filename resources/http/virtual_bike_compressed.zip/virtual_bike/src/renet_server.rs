// Created 2023-7-29, some things copied from `web_server`
// see README on https://github.com/lucaspoffo/renet
use std::{net::{SocketAddr, UdpSocket, IpAddr, Ipv4Addr}, time::{SystemTime, Duration}, thread, sync::{mpsc, Arc, Mutex}};
use renet::{RenetServer, ServerEvent, ConnectionConfig, transport::{ServerAuthentication, ServerConfig}, transport::NetcodeServerTransport, DefaultChannel};
use serde::{Serialize, Deserialize};
use bincode;
use crate::{prelude::*, world::async_messages, resource_interface};

#[derive(Serialize, Deserialize)]
pub enum Request {// All possible requests
	Init,
	ClientUpdate(ClientUpdate),
	Chunk(ChunkRef),
	TogglePlaying,
	RecoverVehicleFromFlip(ClientAuth),
	NewUser {
		name: String,
		psswd: String
	}
}

#[derive(Serialize, Deserialize)]
pub enum Response {// All possible responses
	InitState(StaticData),
	WorldState(WorldSend),
	Chunk(Chunk),
	Err(String)
}

pub struct WorldServer {
	world: Arc<Mutex<World>>,
    server: RenetServer,
    addr: SocketAddr,
	transport: NetcodeServerTransport,
	static_data: StaticData
}

impl WorldServer {
	pub fn init(world_name: &str) -> Self {
		// Load world
		let world_original = World::load(world_name).expect(&format!("Failed to load world \"{}\"", world_name));
		let static_data = world_original.build_static_data();
		let world: Arc<Mutex<World>> = Arc::new(Mutex::new(world_original));
		// Init renet server, mostly copied from https://crates.io/crates/renet
        let server = RenetServer::new(ConnectionConfig::default());
        let addr = SocketAddr::new(IpAddr::V4(Ipv4Addr::new(127, 0, 0, 1)), resource_interface::load_port().expect("Unable to load and parse port.txt"));
		let socket: UdpSocket = UdpSocket::bind(addr).unwrap();
        let server_config = ServerConfig {
            max_clients: 64,
            protocol_id: 0,
            public_addr: addr,
            authentication: ServerAuthentication::Unsecure
        };
		let current_time = SystemTime::now().duration_since(SystemTime::UNIX_EPOCH).unwrap();
		let transport = NetcodeServerTransport::new(current_time, server_config, socket).unwrap();
		Self {
			world,
            server,
			addr,
			transport,
			static_data
		}
	}
	pub fn main_loop(&mut self) {
		// Start world simulation
		//let map_name = self.world.lock().unwrap().map.name.clone();
		let (_world_thread_handle, world_tx, world_rx) = {
			let (tx, rx_remote) = mpsc::channel::<async_messages::ToWorld>();// To thread
			let (tx_remote, rx) = mpsc::channel::<async_messages::FromWorld>();// From thread
			let world_copy = self.world.clone();
			(thread::spawn(move || ((*world_copy).lock().unwrap()).main_loop(rx_remote, tx_remote)), tx, rx)
		};
		// Main loop
		loop {
			thread::sleep(Duration::from_millis(100));// Placeholder to prevent the computer from freezing
			// Receive new messages and update clients, copied from github readme
			let delta_time = Duration::from_millis(100);
			self.server.update(delta_time);
			self.transport.update(delta_time, &mut self.server).unwrap();
			// Receive messages from world simulation thread
			loop {
				match world_rx.try_recv() {// https://doc.rust-lang.org/stable/std/sync/mpsc/struct.Receiver.html
                    Ok(update) => {
						match update {
							async_messages::FromWorld::State(world_send) => {
								// Broadcast state to all clients
								self.server.broadcast_message(DefaultChannel::Unreliable, bincode::serialize(&Response::WorldState(world_send)).unwrap());
							}
							async_messages::FromWorld::Error(e) => panic!("Received the following error from world: {}", e)
						}
                    },
                    Err(error) => {
                        match error {
                            mpsc::TryRecvError::Empty => break,
                            mpsc::TryRecvError::Disconnected => panic!("World receive channel has been disconnected")
                        }
                    }
                }
			}
			// Receive messages from server
			for client_id in self.server.clients_id().iter() {
				// The enum DefaultChannel describe the channels used by the default configuration
				while let Some(message) = self.server.receive_message(*client_id, DefaultChannel::ReliableOrdered) {
					let decoded_result: Result<Request, Box<bincode::ErrorKind>> = bincode::deserialize(&message[..]);
					match decoded_result {
						Ok(decoded) => match decoded {
							Request::Init => {
								println!("Received init request");
								self.server.send_message(*client_id, DefaultChannel::ReliableOrdered, bincode::serialize(&Response::InitState(self.static_data.clone())).expect("Unable to serialize static data with bincode"));
							}
							Request::ClientUpdate(update) => {
								// TODO: authenticate client
								world_tx.send(async_messages::ToWorld::ClientUpdate(update)).expect("Unable to send client update to world");
							}
							Request::Chunk(chunk_ref) => {
								// TODO: change to Reliable
								//println!("Recieved chunk request: {:?}", &chunk_ref);
								match Chunk::load(&chunk_ref, &self.static_data.map.name) {
									Ok(chunk) => {
										let res = Response::Chunk(chunk);
										self.server.send_message(*client_id, DefaultChannel::ReliableOrdered, bincode::serialize(&res).expect("Unable to serialize chunk with bincode"));
									},
									Err(e) => {
										world_tx.send(async_messages::ToWorld::CreateChunk(chunk_ref)).expect("Unable to send chunk creation request to world");
										//Response::Err(format!("Error loading chunk: {}", e.to_string()))
									}
								}
							}
							Request::TogglePlaying => {
								// TODO: authenticate client
								world_tx.send(async_messages::ToWorld::TogglePlaying).expect("Unable to send client update to world");
							}
							Request::RecoverVehicleFromFlip(auth) => {
								// TODO: authenticate client
								world_tx.send(async_messages::ToWorld::RecoverVehicleFromFlip(auth)).expect("Unable to send message to world");
							}
							Request::NewUser{name, psswd} => {
								todo!();// TODO
							}
						},
						Err(e) => {
							let err_string = format!("Error decoding request with bincode: {}", e.to_string());
							self.server.send_message(*client_id, DefaultChannel::ReliableOrdered, err_string.as_bytes().to_vec());
						}
					}
				}
			}
			// Check for client connections/disconnections, TODO more usefull
			while let Some(event) = self.server.get_event() {
				match event {
					ServerEvent::ClientConnected { client_id } => {
						println!("Client {client_id} connected");
					}
					ServerEvent::ClientDisconnected { client_id, reason } => {
						println!("Client {client_id} disconnected: {reason}");
					}
				}
			}
			// Send packets to clients
			self.transport.send_packets(&mut self.server);
		}
	}
}